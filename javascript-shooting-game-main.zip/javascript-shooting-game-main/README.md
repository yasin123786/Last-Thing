https://user-images.githubusercontent.com/29950288/190881837-1fdc32af-f042-46f1-8d1e-714c06ff49f4.mp4

<div align="center">
  <h6>- first 30 seconds -</h6>

  <a href="https://hibi221b.github.io/javascript-shooting-game"><h3>JavaScript Shooting Game</h3></a>
  <p>a 2D side-scroller shooting game using JavaScript, which consist of only index.html.</p>

  <a href="https://github.com/hibi221b/javascript-shooting-game/blob/main/LICENSE"><img src="https://img.shields.io/badge/license-MIT-informational"></a>
  <a href="https://www.w3.org/TR/gamepad/#remapping"><img src="https://img.shields.io/badge/standard%20controller-supported-brightgreen"></a>
  <img src="https://img.shields.io/badge/type-browser%20game-orange">
  <img src="https://img.shields.io/badge/design-responsive-ff69b4">
  <a href="https://hibi221b.github.io/javascript-shooting-game"><img src="https://img.shields.io/badge/site-github%20pages-yellow"></a>
</div>
