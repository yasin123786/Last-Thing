# SpaceFighter

***A simple 2d game simulation of old Classic Video Game, created using using Pure HTML, CSS and Javascript.***

![ezgif com-gif-maker](https://user-images.githubusercontent.com/22127564/198010841-4fdb736e-10af-4b14-8ae6-48249e71aa47.gif)


