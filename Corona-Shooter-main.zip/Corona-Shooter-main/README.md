# Corona-Shooter
Shoot the corona viruses and save the world

![image](https://user-images.githubusercontent.com/64016811/207356281-611235ba-257b-43a0-bcf5-f5e9b1729b69.png)
