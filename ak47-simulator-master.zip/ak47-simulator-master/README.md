# REALISTIC-AK47-SIMULATOR
This is an realistic gun simulator, especially considering that the bullets in the clip are wasted if you change the clip too quickly. Enjoy the shooting, but always keep in mind to make love, not war. 
